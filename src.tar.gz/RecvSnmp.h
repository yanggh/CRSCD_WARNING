#ifndef  __RECVSNMP__H
#define  __RECVSNMP__H
int RecvSnmp();
void Update_timeout();
#endif
