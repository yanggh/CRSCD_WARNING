#ifndef  CONVERT_H
#define  CONVERT_H
int  get_value(char  *str, int length, char** out);
#endif
