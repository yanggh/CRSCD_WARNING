#ifndef  _SONG_H_
#define  _SONG_H_
void  Sig_light();
void  Hop();
void  Song();
#endif

