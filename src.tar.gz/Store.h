#ifndef  __STORE__H
#define  __STORE__H
int  store(const uint8_t *data, const uint16_t data_len);
#endif
